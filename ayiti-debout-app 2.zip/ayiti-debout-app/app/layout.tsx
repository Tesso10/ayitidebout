import type { Metadata, Viewport } from "next";
import { Manrope, Inter } from "next/font/google";
import "./globals.css";

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["500", "700", "800"],
  variable: "--font-manrope",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Ayiti Debout",
  description: "Konprann peyi a. Konnen dwa w. Aji pou lavni.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#123B76",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Remplacer data-domain par le vrai domaine une fois déployé sur Vercel.
  const plausibleDomain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;

  return (
    <html lang="ht">
      <head>
        {plausibleDomain && (
          <script
            defer
            data-domain={plausibleDomain}
            src="https://plausible.io/js/script.js"
          />
        )}
      </head>
      <body className={`${manrope.variable} ${inter.variable} font-body bg-cream text-ink`}>
        <div className="mx-auto min-h-screen max-w-[430px] bg-cream">
          {children}
        </div>
      </body>
    </html>
  );
}
