import Link from "next/link";
import { SITUATIONS } from "@/data/situations";
import ProgressBadge from "@/components/ProgressBadge";
import BottomNav from "@/components/BottomNav";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="flex items-center gap-2.5 px-5 pb-3.5 pt-6">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
          <path d="M12 2 L12 13" stroke="#E7B84B" strokeWidth="2.4" strokeLinecap="round" />
          <path d="M12 2 L7 8" stroke="#123B76" strokeWidth="2.4" strokeLinecap="round" />
          <path d="M12 2 L17 8" stroke="#C73538" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
        <span className="font-display text-[19px] font-extrabold tracking-tight text-blue">
          Ayiti Debout
        </span>
      </header>

      <main className="flex-1 px-5 pb-8">
        <div className="mb-2.5 text-[13px] font-semibold uppercase tracking-wide text-red">
          Konprann Vòt Mwen
        </div>
        <h1 className="mb-3 font-display text-[30px] font-extrabold leading-tight text-blue">
          Konprann peyi a.
          <br />
          Konnen dwa w.
        </h1>
        <p className="mb-6 text-[16px] leading-relaxed text-[#3a4256]">
          Twa ti istwa kout pou konprann eleksyon yo — san pran tèt tankou lekòl.
        </p>

        <div className="relative mb-7 overflow-hidden rounded-[18px] bg-blue px-5 py-4.5 text-cream">
          <div
            className="pointer-events-none absolute -right-8 -top-8 h-[120px] w-[120px] rounded-full"
            style={{ background: "radial-gradient(circle, rgba(231,184,75,.35), transparent 70%)" }}
          />
          <p className="relative z-10 text-[15px] leading-relaxed">
            Nou fèt lib. Se responsabilite nou pou n rete lib — grenn vòt pa grenn vòt.
          </p>
          <div className="relative z-10 mt-2 text-[12px] font-semibold tracking-wide text-gold">
            — Eritaj 1804
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {SITUATIONS.map((s, i) => (
            <Link
              key={s.id}
              href={`/istwa/${s.slug}`}
              className="flex items-center gap-3.5 rounded-2xl border border-[#EAE6DC] bg-white px-4.5 py-4 transition active:scale-[0.98]"
            >
              <ProgressBadge situationId={s.id} index={i} />
              <div>
                <div className="text-[15px] font-semibold text-ink">{s.title}</div>
                <div className="text-[12.5px] text-[#7a8194]">{s.duration}</div>
              </div>
            </Link>
          ))}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
