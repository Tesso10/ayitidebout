import { notFound } from "next/navigation";
import { SITUATIONS } from "@/data/situations";
import IstwaFlow from "@/components/IstwaFlow";

export function generateStaticParams() {
  return SITUATIONS.map((s) => ({ slug: s.slug }));
}

export default function IstwaPage({ params }: { params: { slug: string } }) {
  const situation = SITUATIONS.find((s) => s.slug === params.slug);
  if (!situation) return notFound();

  return <IstwaFlow situation={situation} />;
}
