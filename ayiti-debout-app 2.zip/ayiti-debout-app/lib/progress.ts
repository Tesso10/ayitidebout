// Progression stockée en localStorage — pas de compte utilisateur en Phase 1
// (mode visiteur uniquement, conforme au scope MVP validé).

const KEY = "ayiti_debout_progress_v1";

type ProgressMap = Record<number, boolean>;

function readProgress(): ProgressMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function isSituationDone(id: number): boolean {
  return !!readProgress()[id];
}

export function markSituationDone(id: number) {
  const progress = readProgress();
  progress[id] = true;
  window.localStorage.setItem(KEY, JSON.stringify(progress));

  // Événement analytics — complétion d'une istwa (métrique clé Phase 1).
  trackEvent("Istwa Fini", { istwa_id: String(id) });
}

export function trackEvent(name: string, props?: Record<string, string>) {
  // Plausible expose window.plausible une fois le script chargé (voir layout.tsx).
  const w = window as unknown as {
    plausible?: (name: string, opts?: { props?: Record<string, string> }) => void;
  };
  if (typeof window !== "undefined" && w.plausible) {
    w.plausible(name, props ? { props } : undefined);
  }
}
