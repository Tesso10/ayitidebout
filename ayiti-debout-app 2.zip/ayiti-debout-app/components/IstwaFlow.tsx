"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Situation, SITUATIONS } from "@/data/situations";
import { markSituationDone, trackEvent } from "@/lib/progress";

type Step = "scene" | "pride" | "answered" | "done";

export default function IstwaFlow({ situation }: { situation: Situation }) {
  const router = useRouter();
  const [step, setStep] = useState<Step>("scene");
  const [selected, setSelected] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const index = SITUATIONS.findIndex((s) => s.id === situation.id);
  const correctIndex = situation.options.findIndex((o) => o.correct);
  const isCorrect = selected === correctIndex;

  function playAudio() {
    const el = audioRef.current;
    if (!el) return;
    el.currentTime = 0;
    el.play();
    setPlaying(true);
    trackEvent("Odyo Jwe", { istwa_id: String(situation.id) });
  }

  function selectOption(i: number) {
    setSelected(i);
    setStep("answered");
    trackEvent("Repons Bay", {
      istwa_id: String(situation.id),
      kòrèk: String(i === correctIndex),
    });
  }

  function finish() {
    markSituationDone(situation.id);
    setStep("done");
  }

  return (
    <div className="flex min-h-screen flex-col px-5 pb-8">
      <audio
        ref={audioRef}
        src={situation.audioFile}
        onEnded={() => setPlaying(false)}
        preload="none"
      />

      {step !== "done" && (
        <div className="mb-1 mt-4.5 flex items-center gap-2.5">
          <Link href="/" className="px-1.5 py-1 text-[22px] text-blue">
            ←
          </Link>
          <div className="ml-auto flex gap-1.5">
            {SITUATIONS.map((s, i) => (
              <div
                key={s.id}
                className={`h-[7px] w-[7px] rounded-full ${
                  i === index ? "bg-red" : "bg-[#DED8C8]"
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {step === "scene" && (
        <div className="mt-4 rounded-[20px] bg-white p-[26px_22px] shadow-[0_2px_18px_rgba(18,59,118,0.06)]">
          <div className="mb-2.5 text-[12px] font-bold uppercase tracking-wide text-gold">
            Istwa
          </div>
          <p className="mb-5 text-[16.5px] leading-relaxed text-ink">{situation.scene}</p>
          <div className="mb-5 flex items-center gap-2.5">
            <button
              onClick={playAudio}
              className="flex items-center gap-2 rounded-full border border-[#E3DCC9] bg-cream px-4 py-2.5 text-[13.5px] font-semibold text-blue"
            >
              <span>{playing ? "⏸" : "🔊"}</span>
              {playing ? "Ap li..." : "Koute istwa a"}
            </button>
          </div>
          <div className="mb-5 text-[11.5px] text-[#9a9fae]">
            {situation.voice} — anrejistreman reyèl
          </div>
          <button
            onClick={() => setStep("pride")}
            className="w-full rounded-[14px] bg-red py-[15px] font-display text-[15.5px] font-bold text-white"
          >
            Kontinye
          </button>
        </div>
      )}

      {step === "pride" && (
        <>
          <div className="relative mt-4 overflow-hidden rounded-[18px] bg-blue px-5 py-4.5 text-cream">
            <p className="relative z-10 text-[15px] leading-relaxed">{situation.pride}</p>
            <div className="relative z-10 mt-2 text-[12px] font-semibold tracking-wide text-gold">
              — Eritaj 1804
            </div>
          </div>
          <div className="mt-4 rounded-[20px] bg-white p-[26px_22px] shadow-[0_2px_18px_rgba(18,59,118,0.06)]">
            <p className="mb-3 text-[16.5px] font-semibold text-ink">{situation.question}</p>
            <div className="flex flex-col gap-2.5">
              {situation.options.map((o, i) => (
                <button
                  key={i}
                  onClick={() => selectOption(i)}
                  className="flex items-center gap-3 rounded-[14px] border-[1.5px] border-[#E7E2D5] bg-white px-4 py-3.5 text-left text-[15px] font-medium text-ink"
                >
                  <span className="text-[22px]">{o.emoji}</span>
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      {step === "answered" && (
        <>
          <div className="relative mt-4 overflow-hidden rounded-[18px] bg-blue px-5 py-4.5 text-cream">
            <p className="relative z-10 text-[15px] leading-relaxed">{situation.pride}</p>
            <div className="relative z-10 mt-2 text-[12px] font-semibold tracking-wide text-gold">
              — Eritaj 1804
            </div>
          </div>
          <div className="mt-4 rounded-[20px] bg-white p-[26px_22px] shadow-[0_2px_18px_rgba(18,59,118,0.06)]">
            <p className="mb-3 text-[16.5px] font-semibold text-ink">{situation.question}</p>
            <div className="flex flex-col gap-2.5">
              {situation.options.map((o, i) => {
                const isThisCorrect = i === correctIndex;
                const isThisSelected = i === selected;
                return (
                  <div
                    key={i}
                    className={`flex items-center gap-3 rounded-[14px] border-[1.5px] px-4 py-3.5 text-[15px] font-medium ${
                      isThisCorrect
                        ? "border-green bg-[#F1FAF5] text-ink"
                        : isThisSelected
                        ? "border-red bg-[#FDF2F2] text-ink"
                        : "border-[#E7E2D5] bg-white text-ink"
                    }`}
                  >
                    <span className="text-[22px]">{o.emoji}</span>
                    {o.label}
                  </div>
                );
              })}
            </div>
            <div
              className={`mt-3 rounded-[14px] px-4 py-3.5 text-[14.5px] leading-relaxed ${
                isCorrect ? "bg-[#EAF7F0] text-[#1F6E4C]" : "bg-[#FBEEEE] text-[#8B2A2C]"
              }`}
            >
              {isCorrect ? situation.good : situation.bad}
            </div>
            <button
              onClick={finish}
              className="mt-5 w-full rounded-[14px] bg-red py-[15px] font-display text-[15.5px] font-bold text-white"
            >
              Fini
            </button>
          </div>
        </>
      )}

      {step === "done" && (
        <div className="flex flex-1 flex-col items-center justify-center px-2.5 text-center">
          <div className="mb-4.5 flex h-[88px] w-[88px] items-center justify-center rounded-full bg-green text-[38px]">
            ✓
          </div>
          <h2 className="mb-2 font-display text-[22px] font-bold text-blue">Bravo!</h2>
          <p className="mb-6 max-w-[280px] text-[14.5px] leading-relaxed text-[#5a6172]">
            Ou fin konprann yon nouvo bagay sou peyi w. Chak ti pa se yon pa pou fè Ayiti vanse.
          </p>
          <button
            onClick={() => router.push("/")}
            className="rounded-[14px] bg-red px-8 py-[15px] font-display text-[15.5px] font-bold text-white"
          >
            Retounen
          </button>
        </div>
      )}
    </div>
  );
}
