export default function BottomNav() {
  return (
    <nav className="sticky bottom-0 flex justify-around border-t border-[#EAE6DC] bg-white py-2.5 pb-3.5">
      <div className="flex flex-col items-center gap-0.5 text-[10.5px] font-semibold text-blue">
        <span className="text-[19px]">⌂</span>
        Akèy
      </div>
      <div className="flex flex-col items-center gap-0.5 text-[10.5px] font-semibold text-[#9a9fae]">
        <span className="text-[19px]">☰</span>
        Pwofil
      </div>
    </nav>
  );
}
