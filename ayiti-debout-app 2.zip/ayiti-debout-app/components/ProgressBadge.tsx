"use client";

import { useEffect, useState } from "react";
import { isSituationDone } from "@/lib/progress";

export default function ProgressBadge({
  situationId,
  index,
}: {
  situationId: number;
  index: number;
}) {
  const [done, setDone] = useState(false);

  useEffect(() => {
    setDone(isSituationDone(situationId));
  }, [situationId]);

  return (
    <div
      className={`flex h-9.5 w-9.5 flex-none items-center justify-center rounded-full font-display text-[15px] font-bold text-white ${
        done ? "bg-green" : "bg-blue"
      }`}
      style={{ width: 38, height: 38 }}
    >
      {done ? "✓" : index + 1}
    </div>
  );
}
