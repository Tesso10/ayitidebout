export type Option = {
  label: string;
  emoji: string;
  correct: boolean;
};

export type Situation = {
  id: number;
  slug: string;
  audioFile: string;
  voice: "Vwa Fanm" | "Vwa Gason";
  title: string;
  duration: string;
  pride: string;
  scene: string;
  question: string;
  options: Option[];
  good: string;
  bad: string;
};

// Contenu validé — voir Ayiti-Debout-Script-Anrejistreman.md pour la version
// de référence utilisée lors de l'enregistrement audio (KEP, pas CEP).
export const SITUATIONS: Situation[] = [
  {
    id: 1,
    slug: "poukisa-vot-mwen-enpotan",
    audioFile: "/audio/istwa1_femme.mp3",
    voice: "Vwa Fanm",
    title: "Poukisa vòt mwen enpòtan?",
    duration: "2 minit",
    pride:
      "An 1804, zansèt nou yo goumen pou n te ka libè epi pran desizyon pou tèt nou. Chwazi ki moun k ap dirije se yon fason nou kontinye egzèse libète sa a jodi a.",
    scene:
      "Imajine sa: Jan ap pale ak zanmi l nan yon ti kafe kwen lari a. Li di: \u201cYon sèl vòt pa fè diferans, m pap deplase pou sa.\u201d Zanmi l reponn: \u201cMen si tout moun panse konsa...\u201d",
    question: "Ki sa ki pi bon repons pou Jan?",
    options: [
      { label: "Chak vwa konte, menm si sanble li piti", emoji: "🗳️", correct: true },
      { label: "Jan gen rezon, yon vòt pa chanje anyen", emoji: "🤷", correct: false },
      { label: "Se sèlman gwo moun ki dwe vote", emoji: "🙅", correct: false },
    ],
    good: "Wi, se sa! Lè anpil moun panse \u201cyon sèl vòt pa konte\u201d, se konsa desizyon enpòtan yo pran san vwa pèp la.",
    bad: "Gade sa byen ankò — chak vwa se yon moso nan desizyon final la. Se lè anpil moun pa vote, kèk moun sèl fè chwa pou tout moun.",
  },
  {
    id: 2,
    slug: "kijan-eleksyon-yo-mache",
    audioFile: "/audio/istwa2_gason.mp3",
    voice: "Vwa Gason",
    title: "Kijan eleksyon yo mache an Ayiti?",
    duration: "2 minit",
    pride:
      "Menm jan zansèt nou yo te bati premye leta lib nan Karayib la, jodi a se enstitisyon ki bati pou pwoteje chwa pèp la.",
    scene:
      "Marilène tande nan radyo yo ap pale de \u201ctou eleksyon\u201d. Li pa two konprann kisa sa vle di, ni ki moun ki responsab pou òganize eleksyon yo.",
    question: "Ki enstitisyon ki responsab pou òganize eleksyon an Ayiti?",
    options: [
      { label: "Konsèy Elektoral Pwovizwa (KEP)", emoji: "🏛️", correct: true },
      { label: "Nenpòt patizan politik", emoji: "🚩", correct: false },
      { label: "Radyo ak televizyon yo", emoji: "📻", correct: false },
    ],
    good: "Egzakteman! Se KEP a ki gen responsablite pou òganize ak sipèvize pwosesis eleksyon an, dapre lalwa.",
    bad: "Pa tafèt — se Konsèy Elektoral Pwovizwa a (KEP) ki responsab pou sa, pa yon pati politik ni yon medya.",
  },
  {
    id: 3,
    slug: "ki-wol-kep-a",
    audioFile: "/audio/istwa3_femme.mp3",
    voice: "Vwa Fanm",
    title: "Ki wòl KEP a?",
    duration: "90 segond",
    pride:
      "Yon enstitisyon fò se yon eritaj nou dwe pwoteje — menm jan nou pwoteje libète nou depi 1804.",
    scene:
      "Pyè wè yon pòs sou rezo sosyal ki di KEP a \u201cap chwazi pou pèp la\u201d. Li mande tèt li si se vre.",
    question: "Ki wòl reyèl KEP a?",
    options: [
      { label: "Òganize eleksyon yo san patipri, pa chwazi pou moun", emoji: "⚖️", correct: true },
      { label: "Deside ki moun ki dwe genyen", emoji: "❌", correct: false },
      { label: "Fè kanpay pou yon kandida", emoji: "📣", correct: false },
    ],
    good: "Se sa vre! Wòl KEP a se ògànize ak siveye pwosesis la san patipri — se pèp la ki chwazi ak vòt yo.",
    bad: "Sa pa kòrèk — KEP a pa chwazi pou pèp la, li la pou ògànize eleksyon an jistis pou tout moun.",
  },
];
